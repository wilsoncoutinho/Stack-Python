"""
Stack Attack Reborn — Player Character (Personagem)

Movement, physics, collision resolution, pushing, jumping, and animation.
"""
import pygame
from constants import (
    TILE_SIZE, COLS, ROWS, WIDTH,
    IDLE_FRAMES, WALK_RIGHT_FRAMES, WALK_LEFT_FRAMES,
    PUSH_RIGHT_FRAMES, PUSH_LEFT_FRAMES,
    JUMP_RIGHT_FRAME, JUMP_LEFT_FRAME, STUN_FRAME,
    JUMP_BUFFER_FRAMES, COYOTE_FRAMES, PUSH_HORIZONTAL_SPEED,
    CHAR_DEFS, BOMB_TYPE, POWERUP_HELMET_TYPE,
)
from assets_loader import char_sprites
from audio import (
    play_sound, play_music,
    sound_jump, sound_super_jump, sound_stun, sound_push, sound_explode,
    sound_powerup, sound_helmet, sound_game_over_sfx,
    stop_gameplay_music,
)
from animations import add_particles, register_push_animation
from board import is_cell_occupied
from highscores import highscores, save_highscores
import state


class Personagem:
    PW = TILE_SIZE - 12  # Reduced width (28px) for easier navigation in 1-tile gaps
    PH = TILE_SIZE * 2

    def __init__(self, grid_x, grid_y, char_id):
        self.x = float(grid_x * TILE_SIZE + (TILE_SIZE - self.PW) // 2)
        self.y = float(grid_y * TILE_SIZE)
        self.vel_x = 0.0
        self.vel_y = 0.0
        self.char_id = char_id
        cdef = next(c for c in CHAR_DEFS if c["id"] == char_id)
        self.velocidade = cdef["speed"]
        self.gravidade = 0.5
        self.jump_force = cdef["jump"]
        self.super_jump_force = cdef["super_jump"]
        self.max_super_jumps = cdef["super_jumps"]
        self.max_bombs = cdef.get("bombs", 0)
        self.super_jumps_left = cdef["super_jumps"]
        self.bombs_left = self.max_bombs
        self.no_chao = False
        self.estado = "parado"
        self.dir = 1
        self.frame = 0
        self.anim_tick = 0
        self.alive = True
        self.stun_timer = 0
        self.jump_queued = False
        self.super_jump_queued = False
        self.jump_buffer = 0
        self.super_jump_buffer = 0
        self.coyote_timer = 0
        self.push_cooldown = 0
        self.bomb_cooldown = 0
        self.helmet_timer = 0
        self.frenzy_timer = 0
        self.has_double_jumped = False
        self.sprites = char_sprites[char_id]
        self.num_frames = len(self.sprites)

    # ----- Properties -----
    @property
    def grid_x(self):
        cx = self.x + self.PW / 2
        return max(0, min(COLS - 1, int(cx / TILE_SIZE)))

    @property
    def grid_y(self):
        cy = self.y + self.PH / 2
        return max(0, min(ROWS - 1, int(cy / TILE_SIZE)))

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.PW, self.PH)

    # ----- Actions -----
    def pular(self):
        if self.alive and self.stun_timer <= 0:
            self.jump_queued = True
            self.jump_buffer = JUMP_BUFFER_FRAMES
            play_sound(sound_jump)

    def super_pular(self):
        if self.alive and self.stun_timer <= 0 and self.super_jumps_left > 0:
            self.super_jump_queued = True
            self.super_jump_buffer = JUMP_BUFFER_FRAMES
            play_sound(sound_super_jump)

    def ativar_stun(self, duracao=25):
        self.stun_timer = duracao
        self.vel_x = 0
        play_sound(sound_stun)

    # ----- Crate detection -----
    def _proximo_caixa(self, board_ref):
        probe_top = self.y + self.PH / 3
        probe_height = max(8, self.PH - self.PH // 3)
        contact_slack = 3
        if self.dir == 1:
            probe_left = self.x + self.PW
            probe_right = probe_left + contact_slack
        else:
            probe_right = self.x
            probe_left = probe_right - contact_slack

        # Check falling boxes first
        for box in state.falling_boxes:
            bpx = box.get("px", box["x"] * TILE_SIZE)
            bpy = box.get("py", box["y"] * TILE_SIZE)
            tile_r = pygame.Rect(bpx, bpy, TILE_SIZE, TILE_SIZE)
            overlap_h = min(self.y + self.PH, tile_r.bottom) - max(self.y, tile_r.top)
            if overlap_h > 0:
                if self.dir == 1:
                    edge_gap = tile_r.left - (self.x + self.PW)
                else:
                    edge_gap = self.x - tile_r.right
                if 0 <= edge_gap <= contact_slack:
                    return ("falling", box)

        ty0 = max(0, int(probe_top // TILE_SIZE))
        ty1 = min(ROWS - 1, int((probe_top + probe_height - 1) // TILE_SIZE))
        tx0 = max(0, int(probe_left // TILE_SIZE))
        tx1 = min(COLS - 1, int((probe_right - 1) // TILE_SIZE))
        for ty in range(ty0, ty1 + 1):
            for tx in range(tx0, tx1 + 1):
                if board_ref[ty][tx] != 0:
                    tile_r = pygame.Rect(tx * TILE_SIZE, ty * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    overlap_h = min(probe_top + probe_height, tile_r.bottom) - max(probe_top, tile_r.top)
                    if self.dir == 1:
                        edge_gap = tile_r.left - (self.x + self.PW)
                    else:
                        edge_gap = self.x - tile_r.right
                    if 0 <= edge_gap <= contact_slack and overlap_h >= TILE_SIZE // 3:
                        return ("board", tx, ty)
        return None

    def _pode_empurrar_para(self, board_ref, box_x, box_y):
        dst_x = box_x + self.dir
        if not (0 <= dst_x < COLS):
            return False
        if is_cell_occupied(dst_x, box_y):
            return False
        if box_y > 0 and board_ref[box_y - 1][box_x] != 0:
            return False
        return True

    # ----- Main update -----
    def atualizar(self, teclas, board_ref):
        if not self.alive:
            return

        if self.stun_timer > 0:
            self.stun_timer -= 1
            self.estado = "stun"
            self.vel_x = 0
            self._aplicar_fisica(board_ref)
            return

        if self.no_chao:
            self.coyote_timer = COYOTE_FRAMES
        elif self.coyote_timer > 0:
            self.coyote_timer -= 1

        if self.jump_buffer > 0:
            self.jump_buffer -= 1
        if self.super_jump_buffer > 0:
            self.super_jump_buffer -= 1
        if self.bomb_cooldown > 0:
            self.bomb_cooldown -= 1
        if self.helmet_timer > 0:
            self.helmet_timer -= 1.0 / 60.0

        if self.push_cooldown > 0:
            moving_forward = (self.dir == -1 and teclas.get("esquerda")) or (self.dir == 1 and teclas.get("direita"))
            moving_backward = (self.dir == -1 and teclas.get("direita")) or (self.dir == 1 and teclas.get("esquerda"))
            if moving_forward:
                self.vel_x = PUSH_HORIZONTAL_SPEED * self.dir
                self.estado = "empurrando"
            elif moving_backward:
                self.push_cooldown = 0
                self.vel_x = -self.velocidade if self.dir == 1 else self.velocidade
                self.dir = -self.dir
                self.estado = "andando"
            else:
                self.vel_x = 0
                self.estado = "parado"
            if self.push_cooldown > 0:
                self.push_cooldown -= 1
        else:
            if teclas.get("esquerda"):
                self.vel_x = -self.velocidade
                self.dir = -1
            elif teclas.get("direita"):
                self.vel_x = self.velocidade
                self.dir = 1
            else:
                # Passive: Lizzie slides when stopping
                if self.char_id == "lizzie" and abs(self.vel_x) > 0.5:
                    self.vel_x *= 0.85
                else:
                    self.vel_x = 0
                
                if self.no_chao:
                    self.estado = "parado"

        if self.push_cooldown <= 0:
            prox = self._proximo_caixa(board_ref) if self.vel_x != 0 else None
            wants_to_push = prox is not None
            if wants_to_push:
                ptype = prox[0]
                pushed = False
                if ptype == "board":
                    bx, by = prox[1], prox[2]
                    if self._pode_empurrar_para(board_ref, bx, by):
                        self._empurrar_caixa(board_ref, bx, by, bx + self.dir)
                        self.push_cooldown = 16
                        pushed = True
                elif ptype == "falling":
                    box = prox[1]
                    bx = box["x"]
                    nnx = bx + self.dir
                    if 0 <= nnx < COLS:
                        ty0 = int(box["py"] // TILE_SIZE)
                        ty1 = min(ROWS - 1, int((box["py"] + TILE_SIZE - 1) // TILE_SIZE))
                        can_push_f = True
                        for ty in range(ty0, ty1 + 1):
                            if board_ref[ty][nnx] != 0:
                                can_push_f = False
                        if can_push_f and not any(
                            b["x"] == nnx and abs(b["py"] - box["py"]) < TILE_SIZE
                            for b in state.falling_boxes
                        ):
                            box["x"] = nnx
                            self.push_cooldown = 16
                            pushed = True
                if pushed:
                    # Passive: Pete has faster push cooldown
                    self.push_cooldown = 12 if self.char_id == "pete" else 20
                    # Passive: Frank pushes at his full walk speed
                    self.vel_x = (self.velocidade if self.char_id == "frank" else PUSH_HORIZONTAL_SPEED) * self.dir
                    self.estado = "empurrando"
                    play_sound(sound_push)
                else:
                    self.vel_x = 0
            elif self.vel_x != 0 and self.no_chao:
                self.estado = "andando"
            elif self.vel_x == 0 and self.no_chao:
                self.estado = "parado"

        can_jump_from_ground = self.no_chao or self.coyote_timer > 0
        if self.super_jump_buffer > 0 and can_jump_from_ground and self.super_jumps_left > 0:
            self.vel_y = self.super_jump_force
            self.no_chao = False
            self.coyote_timer = 0
            self.estado = "pulando"
            self.super_jumps_left -= 1
            self.super_jump_queued = False
            self.super_jump_buffer = 0
            self.jump_queued = False
            self.jump_buffer = 0
            self.jump_queued = False
            self.jump_buffer = 0
        elif self.jump_buffer > 0:
            # Passive: Will has a double jump
            if self.char_id == "will" and not self.no_chao and not self.has_double_jumped:
                self.vel_y = self.jump_force * 0.9
                self.has_double_jumped = True
                self.estado = "pulando"
                self.jump_queued = False
                self.jump_buffer = 0
                play_sound(sound_jump)
            elif can_jump_from_ground:
                self.vel_y = self.jump_force
                self.no_chao = False
                self.coyote_timer = 0
                self.estado = "pulando"
                self.jump_queued = False
                self.jump_buffer = 0

        # Passive: Cath gains speed frenzy
        if self.frenzy_timer > 0:
            self.frenzy_timer -= 1
            if self.estado == "andando":
                self.vel_x *= 1.4

        self._aplicar_fisica(board_ref)

    # ----- Physics -----
    def _aplicar_fisica(self, board_ref):
        self.vel_y += self.gravidade
        if self.vel_y > TILE_SIZE:
            self.vel_y = float(TILE_SIZE)

        self.x += self.vel_x
        self._resolver_horizontal(board_ref)

        self.y += self.vel_y
        self._resolver_vertical(board_ref)

        if self.x < 0:
            self.x = 0
            self.vel_x = 0
        if self.x + self.PW > WIDTH:
            self.x = float(WIDTH - self.PW)
            self.vel_x = 0

        self._atualizar_anim()

    def _resolver_horizontal(self, board_ref):
        r = self.rect
        y0 = max(0, r.top // TILE_SIZE)
        y1 = min(ROWS - 1, (r.bottom - 1) // TILE_SIZE)
        x0 = max(0, r.left // TILE_SIZE)
        x1 = min(COLS - 1, (r.right - 1) // TILE_SIZE)
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if board_ref[ty][tx] != 0:
                    tile_r = pygame.Rect(tx * TILE_SIZE, ty * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    if not r.colliderect(tile_r):
                        continue
                    if board_ref[ty][tx] == POWERUP_HELMET_TYPE:
                        self.helmet_timer = 5.0
                        board_ref[ty][tx] = 0
                        state.score += 50
                        play_sound(sound_helmet)
                        state.screen_shake = 10
                        add_particles(self.x + self.PW / 2, self.y + self.PH / 2, (100, 255, 100), 20)
                        continue
                    if self.vel_x > 0:
                        self.x = float(tile_r.left - self.PW)
                    elif self.vel_x < 0:
                        self.x = float(tile_r.right)
                    else:
                        d_left = r.right - tile_r.left
                        d_right = tile_r.right - r.left
                        if d_left < d_right:
                            self.x = float(tile_r.left - self.PW)
                        else:
                            self.x = float(tile_r.right)
                    self.vel_x = 0
                    return

        # Check falling boxes horizontally
        r = self.rect
        for box in state.falling_boxes:
            bpx = box.get("px", box["x"] * TILE_SIZE)
            bpy = box.get("py", box["y"] * TILE_SIZE)
            tile_r = pygame.Rect(bpx, bpy, TILE_SIZE, TILE_SIZE)
            if not r.colliderect(tile_r):
                continue
            overlap_h = min(r.bottom, tile_r.bottom) - max(r.top, tile_r.top)
            if overlap_h > 0:
                if self.vel_x > 0:
                    self.x = float(tile_r.left - self.PW)
                elif self.vel_x < 0:
                    self.x = float(tile_r.right)
                else:
                    d_left = r.right - tile_r.left
                    d_right = tile_r.right - r.left
                    if d_left < d_right:
                        self.x = float(tile_r.left - self.PW)
                    else:
                        self.x = float(tile_r.right)
                self.vel_x = 0
                return

        # Check boxes in push animations horizontally
        for anim in state.push_animations:
            tile_r = pygame.Rect(anim["px"], anim["py"], TILE_SIZE, TILE_SIZE)
            if not r.colliderect(tile_r):
                continue
            overlap_h = min(r.bottom, tile_r.bottom) - max(r.top, tile_r.top)
            if overlap_h > 0:
                if self.vel_x > 0:
                    self.x = float(tile_r.left - self.PW)
                elif self.vel_x < 0:
                    self.x = float(tile_r.right)
                else:
                    d_left = r.right - tile_r.left
                    d_right = tile_r.right - r.left
                    if d_left < d_right:
                        self.x = float(tile_r.left - self.PW)
                    else:
                        self.x = float(tile_r.right)
                self.vel_x = 0
                return

    def _resolver_vertical(self, board_ref):
        self.no_chao = False
        r = self.rect
        y0 = max(0, r.top // TILE_SIZE)
        y1 = min(ROWS - 1, (r.bottom - 1) // TILE_SIZE)
        x0 = max(0, r.left // TILE_SIZE)
        x1 = min(COLS - 1, (r.right - 1) // TILE_SIZE)
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if board_ref[ty][tx] == 0:
                    continue
                tile_r = pygame.Rect(tx * TILE_SIZE, ty * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                if not r.colliderect(tile_r):
                    continue
                if board_ref[ty][tx] == POWERUP_HELMET_TYPE:
                    self.helmet_timer = 5.0
                    board_ref[ty][tx] = 0
                    state.score += 50
                    play_sound(sound_helmet)
                    continue
                if self.vel_y > 0:
                    self.y = float(tile_r.top - self.PH)
                    self.vel_y = 0
                    self.no_chao = True
                elif self.vel_y < 0:
                    self.y = float(tile_r.bottom)
                    self.vel_y = 0
                return

        # Check boxes in push animations vertically
        for anim in state.push_animations:
            tile_r = pygame.Rect(anim["px"], anim["py"], TILE_SIZE, TILE_SIZE)
            if not r.colliderect(tile_r):
                continue
            if self.vel_y > 0:
                self.y = float(tile_r.top - self.PH)
                self.vel_y = 0
                self.no_chao = True
            elif self.vel_y < 0:
                self.y = float(tile_r.bottom)
                self.vel_y = 0
            return

        floor_y = ROWS * TILE_SIZE
        if self.y + self.PH >= floor_y:
            self.y = float(floor_y - self.PH)
            self.vel_y = 0
            self.no_chao = True
            self.has_double_jumped = False

    # ----- Push crate -----
    def _empurrar_caixa(self, board_ref, from_x, from_y, to_x):
        crate_type = board_ref[from_y][from_x]
        board_ref[from_y][from_x] = 0
        landing_y = from_y
        while landing_y < ROWS - 1 and board_ref[landing_y + 1][to_x] == 0:
            landing_y += 1
        bt = 0
        if crate_type == BOMB_TYPE:
            bt = state.bomb_timers[from_y][from_x]
            state.bomb_timers[from_y][from_x] = 0
        register_push_animation(from_x, from_y, to_x, landing_y, crate_type, bomb_timer=bt)

    # ----- Animation -----
    def _atualizar_anim(self):
        prev = getattr(self, '_last_estado', None)
        if prev != self.estado:
            self.anim_tick = 0
            self._last_estado = self.estado
            self.frame = 0

        self.anim_tick += 1
        walk_rate = max(2, int(5.5 - self.velocidade * 0.5))

        if self.estado == "empurrando":
            tick_rate = walk_rate + 3
        elif self.estado == "andando":
            tick_rate = walk_rate
        elif self.estado == "pulando":
            tick_rate = 999
        else:
            tick_rate = 10

        if self.anim_tick >= tick_rate:
            self.anim_tick = 0
            if self.estado == "andando":
                self.frame = (self.frame + 1) % len(WALK_RIGHT_FRAMES)
            elif self.estado == "empurrando":
                self.frame = (self.frame + 1) % len(PUSH_RIGHT_FRAMES)
            elif self.estado == "parado":
                self.frame = (self.frame + 1) % len(IDLE_FRAMES)

    def get_sprite(self):
        if not self.alive:
            idx = min(STUN_FRAME, self.num_frames - 1)
            return self.sprites[idx]
        if self.estado == "pulando":
            idx = JUMP_RIGHT_FRAME if self.dir == 1 else JUMP_LEFT_FRAME
            return self.sprites[min(idx, self.num_frames - 1)]
        if self.estado == "stun":
            return self.sprites[min(STUN_FRAME, self.num_frames - 1)]
        if self.estado == "empurrando":
            frames = PUSH_RIGHT_FRAMES if self.dir == 1 else PUSH_LEFT_FRAMES
            idx = frames[self.frame % len(frames)]
            return self.sprites[min(idx, self.num_frames - 1)]
        if self.estado == "andando":
            frames = WALK_RIGHT_FRAMES if self.dir == 1 else WALK_LEFT_FRAMES
            idx = frames[self.frame % len(frames)]
            return self.sprites[min(idx, self.num_frames - 1)]
        idx = IDLE_FRAMES[self.frame % len(IDLE_FRAMES)]
        return self.sprites[min(idx, self.num_frames - 1)]

    # ----- Falling crate collision -----
    def check_falling_collision(self, falling_boxes_list):
        if not self.alive:
            return
        body_left = self.x + 8
        body_right = self.x + self.PW - 8
        body_top = self.y

        for box in falling_boxes_list[:]:
            box_px = box.get("px", box["x"] * TILE_SIZE)
            box_py = box.get("py", box["y"] * TILE_SIZE)
            crate_left = box_px + 4
            crate_right = box_px + TILE_SIZE - 4
            if body_right < crate_left or body_left > crate_right:
                continue
            crate_bottom = box_py + TILE_SIZE
            if crate_bottom < body_top or box_py > body_top + 16:
                continue

            if box["type"] == POWERUP_HELMET_TYPE:
                self.helmet_timer = 5.0
                state.score += 50
                play_sound(sound_powerup)
                state.screen_shake = 10
                add_particles(box_px + TILE_SIZE / 2, box_py + TILE_SIZE / 2, (100, 255, 100), 20)
                falling_boxes_list.remove(box)
                continue

            stomp_hit = (
                self.vel_y >= 0
                and (self.y + self.PH) <= box_py + 16
                and (self.y + self.PH / 2) < (box_py + TILE_SIZE / 2)
            )
            if stomp_hit:
                falling_boxes_list.remove(box)
                state.score += 10
                play_sound(sound_explode)
                self.vel_y = min(self.vel_y, -4)
                # Passive: Cath gets frenzy boost on stomp
                if self.char_id == "cath":
                    self.frenzy_timer = 120
                continue

            if self.helmet_timer > 0:
                falling_boxes_list.remove(box)
                state.score += 10
                play_sound(sound_explode)
                if self.vel_y < 0:
                    self.vel_y = 2
                state.floating_explosions.append({"px": box_px, "py": box_py, "timer": 20})
                continue

            # Death
            self.alive = False
            from game import stop_timers
            stop_timers()
            stop_gameplay_music()
            play_sound(sound_game_over_sfx)
            play_music("gameover.mid")
            char_id = self.char_id
            current_hs = highscores.get(char_id, 0)
            if state.score > current_hs:
                highscores[char_id] = state.score
                save_highscores(highscores)
            return

    # ----- Bomb placement -----
    def try_place_bomb(self, board_ref):
        if self.bombs_left > 0 and self.bomb_cooldown <= 0:
            tx = self.grid_x + self.dir
            ty = self.grid_y
            tx = max(0, min(COLS - 1, tx))
            ty = max(0, min(ROWS - 1, ty))
            if tx == self.grid_x:
                return False
            if board_ref[ty][tx] == BOMB_TYPE:
                return False
            else:
                board_ref[ty][tx] = BOMB_TYPE
                state.bomb_timers[ty][tx] = 180
            self.bombs_left -= 1
            self.bomb_cooldown = 40
            from audio import sound_bomb
            play_sound(sound_bomb)
            return True
        return False
